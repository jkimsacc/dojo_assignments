﻿using System;

namespace fund_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //print 1 - 255
            // for (int i = 1; i < 256; i++){
            //     Console.WriteLine(i);
            // }

            //print divisible to 3 || 5 in range 1-100
            // for (int i = 1; i < 101; i ++){
            //     if (i % 3 == 0 || i % 5 == 0){
            //         Console.WriteLine(i);
            //     }
            // }

            //print fizz 3 buzz 5, fizzbuzz
            // for (int i = 1; i < 101; i++)
            // {
            //     if (i % 3 == 0 && i % 5 == 0)
            //     {
            //         Console.WriteLine("{0} fizzbuzz", i);        
            //     }
            //     else if (i % 3 == 0){
            //         Console.WriteLine("{0} fizz", i);
            //     }
            //     else if (i % 5 == 0){
            //         Console.WriteLine("{0} buzz", i);
            //     }
            // }
        }

    }
}
