using System;

namespace humans{
    public class Samurai : Human {
        public Samurai(string input) : base(input){
            health = 200;
        }
        public void death_blow(object human){
            Human target = human as Human;
            if (target.health < 50){
                target.health = 0;
            }
            else{
                Console.WriteLine("Nothing Happend");
            }
        }
        public void method(){
            health = 200;
        } 
    }
}