using System;

namespace humans{
    public class Wizard : Human {
        public Wizard(string input) : base(input){
            health = 50;
            intelligence = 25;
        }
        public void Heal(){
            health += 10*intelligence;
        }
        public void Fireball(object human){
            Human target = human as Human;
            if(target != null){
                Random rand = new Random();
                target.health -= rand.Next(20, 51);
            }

        }
    }
}