﻿using System;

namespace humans
{
    class Program
    {
        static void Main(string[] args)
        {
            Wizard nick = new Wizard("Nick");
            Console.WriteLine(nick.name);   
        }
    }
}
