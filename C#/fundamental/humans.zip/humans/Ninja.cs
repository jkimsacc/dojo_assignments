using System;

namespace humans{
    public class Ninja : Human {
        public Ninja(string input) : base(input){
            dexterity = 175;
        }
        public void Sucklife(object human){
            Human target = human as Human;
            Random rand = new Random();
            if ( rand.Next(0,2) == 1){
                target.health -= 75;
                health = 75;
            }
            else{
                target.health -= 10;
                health += 10;
            }
        }
        public void GetAway(){
            health += 15;
        } 
    }
}