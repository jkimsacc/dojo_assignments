﻿using System;

namespace _13
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = {1,2,3,4,5,6,7,-2,1};
            // print();
            // printOdd();
            // sum();
            // printArr(numbers);
            // findMax(numbers);
            // average(numbers);
            // Console.WriteLine(arrayOdd());
            greaterThan(numbers, 5);
            minMaxAvg(numbers);
            // shift(numbers);
            // Console.WriteLine(numToString(numbers));

        }
        public static void print() {
            for(int i = 1; i <= 255; i++) {
                Console.WriteLine(i);
            }
        }

        public static void printOdd() {
            for(int i = 1; i <= 255; i+=2) {
                Console.WriteLine(i);
            }
        }

        public static void sum() {
            int sum = 0;
            Console.WriteLine(sum);
            for(int i = 0; i <= 255; i++) {
                Console.WriteLine(sum += i);
            }
        }

        public static void printArr(int[] arr) {
            foreach(int element in arr) {
                Console.WriteLine(element);
            }
        }

        public static void findMax(int[] arr) {
            int max = arr[0];
            foreach(int number in arr) {
                if(number > max) {
                    max = number;
                }
            }
            Console.WriteLine(max);
        }

        public static void average(int[] arr) {
            int sum = 0;
            for(int i = 0; i < arr.Length; i++) {
                sum += arr[i];
            }
            Console.WriteLine(sum/arr.Length);
        }

        public static int[] arrayOdd() {
            int[] oddArray = new int[128];
            int index = 0;
            for(int i = 1; i <= 255; i++) {
                if(i % 2 == 1) {
                    oddArray[index] = i;
                    index++;
                }
            }
            return oddArray;
        }

        public static void greaterThan(int[] arr, int y) {
            int count = 0;
            for(int i = 0; i < arr.Length; i++) {
                if(arr[i] > y) {
                    count++;
                }
            }
            Console.WriteLine(count);
        }

        public static void square(int[] arr) {
            for(int i = 0; i < arr.Length; i++) {
                arr[i] *= arr[i];
            }
        }

        public static void noNeg(int[] arr) {
            for(int i = 0; i < arr.Length; i++) {
                if(arr[i] < 0) {
                    arr[i] = 0;
                }
            }
        }

        public static void minMaxAvg(int[] arr) {
            int min = arr[0];
            int max = arr[0];
            int sum = 0;
            for(int i = 0; i < arr.Length; i++) {
                int temp = arr[i];
                if(temp < min) {
                    min = temp;
                }
                if(temp > max) {
                    max = temp;
                }
                sum += temp;
            }

            Console.WriteLine("The max is {0}, the min is {1}, the average is {2}.", max, min, (double)sum/(double)arr.Length);
        }

        public static void shift(int[] arr) {
            for(int i = 0; i < arr.Length - 1; i++) {
                arr[i] = arr[i+1];
            }
            arr[arr.Length -1] = 0;
        }

        public static object[] numToString(int[] arr) {
            object[] newArr = new object[arr.Length];
            for(int i = 0; i < arr.Length; i++) {
                if(arr[i] < 0) {
                    newArr[i] = "Dojo";
                }else {
                    newArr[i] = arr[i];
                }
            }
            return newArr;
        }
    }
}