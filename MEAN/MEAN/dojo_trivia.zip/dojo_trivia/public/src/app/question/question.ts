export class Question {
   constructor(
      public _id: string ="",
      public question: string ="",
      public answer: string = "",
      public fake_answer1 : string = "",
      public fake_answer2 : string = "",
   ) {}
}
